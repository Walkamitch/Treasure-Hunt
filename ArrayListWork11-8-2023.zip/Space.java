public class Space {
    private LivingThing occupant;
    private Treasure cache;


    public Space() {
        this.occupant = null;
        this.cache = null;
    }


    public Space(LivingThing occupant) {
        this.occupant = occupant;
        this.cache = null;
    }

    public Space(Treasure t){

    }

    public void setOccupant(LivingThing occupant) {
        this.occupant = occupant;
    }


    public LivingThing getOccupant() {
        return occupant;
    }


    public String getConsoleStr() {
        if (occupant == null) {
            return "-";
        } else {
            return occupant.getConsoleStr();
        }
    }

    public Treasure getCache() {
        return cache;
    }

    public void setCache(Treasure cache) {
        this.cache = cache;
    }
    public String getConsoleStr(boolean reveal){
        if(reveal == true) {
            if (occupant != null) {
                return occupant.getConsoleStr();
            }else{
                return cache.getConsoleStr();
            }
        }else{
            return "-";
        }
    }
}
