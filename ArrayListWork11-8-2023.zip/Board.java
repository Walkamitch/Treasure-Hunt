import java.util.ArrayList;
import java.util.Scanner;

public class Board {
    private ArrayList<ArrayList<Space>> board;
    private int gazooRow;
    private int gazooCol;

    public Board(int numRows, int numCols) {
        board = new ArrayList<>();

        for (int i = 0; i < numRows; i++) {
            ArrayList<Space> row = new ArrayList<>();
            board.add(row);

            for (int j = 0; j < numCols; j++) {
                row.add(new Space());
            }
        }

        LivingThing gazoo = new LivingThing("Gazoo", 20, ConsoleColors.GREEN);
        gazooRow = 0;
        gazooCol = 0;
        board.get(gazooRow).get(gazooCol).setOccupant(gazoo);
    }

    public boolean move(char m) {
        int newGazooRow = gazooRow;
        int newGazooCol = gazooCol;

        switch (Character.toLowerCase(m)) {
            case 'w':
                newGazooRow--;
                break;
            case 'a':
                newGazooCol--;
                break;
            case 's':
                newGazooRow++;
                break;
            case 'd':
                newGazooCol++;
                break;
            default:
                return false;
        }

        if (isValidMove(newGazooRow, newGazooCol)) {
            board.get(gazooRow).get(gazooCol).setOccupant(null);
            gazooRow = newGazooRow;
            gazooCol = newGazooCol;
            board.get(gazooRow).get(gazooCol).setOccupant(new LivingThing("Gazoo", 20, ConsoleColors.GREEN));
            return true;
        } else {
            return false;
        }
    }

    private boolean isValidMove(int row, int col) {
        return row >= 0 && row < board.size() && col >= 0 && col < board.get(0).size();
    }

    public void printBoard() {
        for (ArrayList<Space> row : board) {
            for (Space space : row) {
                System.out.print(space.getConsoleStr() + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Board board = new Board(8, 9);
        board.printBoard();
        System.out.println();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Enter a move (w/a/s/d to move Gazoo, q to quit): ");
            char move = scanner.next().charAt(0);

            if (move == 'q') {
                break;
            }

            if (board.move(move)) {
                System.out.println("Moved Gazoo " + move);
                board.printBoard();
            } else {
                System.out.println("Invalid move " + move);
            }
        }

        scanner.close();
    }
}
